package util;

import java.util.List;

public class JsonTreeData {
   public String id;
   public String pid;
   public String text;
   public List<JsonTreeData> children;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getPid() {
	return pid;
}
public void setPid(String pid) {
	this.pid = pid;
}
public String getText() {
	return text;
}
public void setText(String text) {
	this.text = text;
}
public List<JsonTreeData> getChildren() {
	return children;
}
public void setChildren(List<JsonTreeData> children) {
	this.children = children;
}
   
}
