package Dao;

import BaseDao.BaseHibernateDao;
import Entity.LuruBiao;

public interface LuRuDao extends BaseHibernateDao<LuruBiao>{

}
