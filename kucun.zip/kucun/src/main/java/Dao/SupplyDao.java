package Dao;

import BaseDao.BaseHibernateDao;
import Entity.Supply;

public interface SupplyDao extends BaseHibernateDao<Supply>{

}
