package Dao;

import BaseDao.BaseHibernateDao;
import Entity.IsGoods;

public interface IsGoodsDao extends BaseHibernateDao<IsGoods>{

}
