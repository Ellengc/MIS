package Dao;

import BaseDao.BaseHibernateDao;
import Entity.MenAndKucun;

public interface KuCunDao extends BaseHibernateDao<MenAndKucun> {
  
}
