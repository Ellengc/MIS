package Dao;

import BaseDao.BaseHibernateDao;
import Entity.Dingdan;

public interface DingDanDao extends BaseHibernateDao<Dingdan>{
    
}
