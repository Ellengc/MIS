package Dao;

import BaseDao.BaseHibernateDao;
import Entity.Customer;

public interface CustomerDao extends BaseHibernateDao<Customer>{

}
