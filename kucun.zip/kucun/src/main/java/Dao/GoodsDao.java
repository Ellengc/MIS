package Dao;

import BaseDao.BaseHibernateDao;
import Entity.Goods;

public interface GoodsDao extends BaseHibernateDao<Goods>{

}
