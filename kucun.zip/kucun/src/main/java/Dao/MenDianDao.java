package Dao;

import BaseDao.BaseHibernateDao;
import Entity.MenDian;

public interface MenDianDao extends BaseHibernateDao<MenDian>{

}
