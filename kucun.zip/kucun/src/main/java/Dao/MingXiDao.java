package Dao;

import BaseDao.BaseHibernateDao;
import Entity.XiaoShouMingXi;

public interface MingXiDao extends BaseHibernateDao<XiaoShouMingXi>{

}
