package Action;

import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;

import javax.jws.WebParam.Mode;

import Entity.Customer;

public class CustomerAction extends BaseAction<Customer>{
    
	private String cname;
	private String cphone;
	private String caddress;
	
	public String getAllCustomers(){
		lists=customerService.getAllCustomers();
		return "getAllCustomers";
		
	}
	
	
	public String addOneCustomer() throws UnsupportedEncodingException{
		
		System.out.println(caddress+cphone);

		Customer customer=new Customer(cname,(Integer.parseInt(cphone)),caddress);
	
		Serializable a = customerService.addOneCustomer(customer);
		
		System.out.println(a);
		
		inputStream =  (a==null)
    			? new ByteArrayInputStream("false"
    				.getBytes("UTF-8"))
    			: new ByteArrayInputStream("true"
    				.getBytes("UTF-8"));
		return "addOneCustomer";
	}


	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}





	public String getCphone() {
		return cphone;
	}


	public void setCphone(String cphone) {
		this.cphone = cphone;
	}


	public String getCaddress() {
		return caddress;
	}


	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	
	
}
