package Action;

import Entity.Supply;

public class SupplyAction extends BaseAction<Supply>{
    public int id;
	
	
	public String getAllSupply(){
		lists=supplyService.getAllSupply();
		maps.put("rows", lists);
		maps.put("total", lists.size());
		return "getAllSupply";
	}
	
	
	public String apply(){
		model=supplyService.getById(id);
		model.setState("�ѷ���");
		model.getMenAndKucun().setState2(2);
		int a=model.getMenAndKucun().getKucun();
		model.getMenAndKucun().setKucun(a+model.getMenAndKucun().getQ());
		kuCunService.update(model.getMenAndKucun());
		supplyService.update(model);
		return "apply";
	}
}
