package Action;

import java.io.Serializable;
import java.util.Date;

import Entity.Customer;
import Entity.Dingdan;
import Entity.Goods;
import Entity.LuruBiao;
import Entity.MenAndKucun;
import Entity.MenDian;
import Entity.User;
import Entity.XiaoShouMingXi;
import util.SearchBackge;

public class LuRuAction extends BaseAction<LuruBiao>{
	
	public String  mid;
	public String gid;
	int a=0;
	public int id;
	public int xiaoliang;
	public Double price;
	public String address;
	public Date time;
	public String[] ids; 
	public int cid;
	public String state;
	
	public String getKongBiao(){
	if(state!=null){
	    lists=luRuService.getAllLuRu();
	    if(lists.size()==0){
			return "getKongBiao";
	    }else{
	      
	 	    MenDian menDian=(((User) session.get("user")).getRenquanxian().getMenDian());
	 	    Customer customer=customerService.getbyid(cid);
	 	    Dingdan dingdan=new Dingdan(customer, menDian, address, time);
	 	    dingDanService.addDingdan(dingdan);
	 	    for(int i=0;i<lists.size();i++){
	 	    	LuruBiao luruBiao=lists.get(i);
	 			SearchBackge searchBackge=new SearchBackge();
	 			String canshu[][]={{"gid","mid"},{String.valueOf(luruBiao.getGood().getId()),String.valueOf(menDian.getId())}};
	 			String hql= searchBackge.selectByParam(canshu,"MenAndKucun");
	 			System.out.println(hql+"aaaaaaaaa");
	 			MenAndKucun menAndKucun1=kuCunService.getOneKuCun(hql);
	 			a=menAndKucun1.getKucun();
	 	        menAndKucun1.setKucun(a-luruBiao.getShouLiang());
	 	        kuCunService.update(menAndKucun1);
	 	    	XiaoShouMingXi xiaoShouMingXi=new XiaoShouMingXi(luruBiao.ShouLiang,luruBiao.getGood(),dingdan,luruBiao.getPrice());
	 	        mingXiService.addMingXi(xiaoShouMingXi);
	 	    }
	 	    luRuService.deleteAll();
	 		return "getKongBiao";
	    	
	    }
	   
	}else{
		lists=luRuService.getAllLuRu();
		return "getKongBiao";
	}
	}
	
	public String update(){
		System.out.println("update!!!!!!!!!!!!!!!!!!!!!!");
	    model=luRuService.getOne(id);
	    Goods goods=goodsService.getOnegood((Integer.parseInt(gid)));
	    model.setGood(goods);
		model.setPrice(price);
		model.setShouLiang(xiaoliang);
		model.setAddress(address);
		luRuService.update(model);
		return "update";
	}
	public String add(){
		mid=(String.valueOf(((User) session.get("user")).getRenquanxian().getMenDian().getId()));
		SearchBackge searchBackge=new SearchBackge();
		String canshu[][]={{"gid","mid"},{gid,mid}};
		String hql= searchBackge.selectByParam(canshu,"MenAndKucun");
		System.out.println(hql+"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		MenAndKucun menAndKucun1=kuCunService.getOneKuCun(hql);
		a=menAndKucun1.getKucun();
		System.out.println(gid+"999999999");
		Goods goods=goodsService.getOnegood((Integer.parseInt(gid)));
	    LuruBiao insertKongbiao=new LuruBiao(goods,a,xiaoliang,price);
	    insertKongbiao.setCustomer(customerService.getbyid(cid));;
		luRuService.save(insertKongbiao);
		return "add";
	}
	
	public String delete(){
		System.out.println(ids[0]);
		luRuService.deletes(ids[0]);
		return "delete";
	}
	
	
}
