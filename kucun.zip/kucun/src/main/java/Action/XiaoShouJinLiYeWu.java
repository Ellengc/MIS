package Action;

import java.io.IOException;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import Entity.Dingdan;
import Entity.MenDian;
import Entity.User;
import Entity.XiaoShouMingXi;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class XiaoShouJinLiYeWu extends BaseAction<XiaoShouMingXi> {
	public String gid;
	public String mid;
	public String cid;
	public int id;
	public int did;
	public String getMenDianMingXi() throws IOException {
		String json = null;
		JSONArray rootArray = new JSONArray();
		mid = (String.valueOf(((User) session.get("user")).getRenquanxian().getMenDian().getId()));
		if (id == 0) {
			List<Dingdan> listss = dingDanService.getMenDianDingdan("from Dingdan d where d.menDian.id=" + mid);
			for (Dingdan dingdan : listss) {
				/*
				 * System.out.println(dingdan.getId()+"�����������������"); String hql=
				 * "from XiaoShouMingXi x where x.dingdan.id="+dingdan.getId();
				 * lists2=mingXiService.getAllMingXi(hql); JSONArray
				 * childArray=new JSONArray(); for(XiaoShouMingXi
				 * xiaoShouMingXi:lists2){ childArray.add(xiaoShouMingXi); }
				 * JSONObject currentObj = JSONObject.fromObject(dingdan);
				 * currentObj.put("children",childArray);
				 */
				JSONObject currentObj = JSONObject.fromObject(dingdan);
				currentObj.put("state", "closed");
				rootArray.add(currentObj);
			}
			json = rootArray.toString();
			ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
			ServletActionContext.getResponse().setContentType("text/json");
			ServletActionContext.getResponse().getWriter().write(json);
			ServletActionContext.getResponse().getWriter().flush();
			ServletActionContext.getResponse().getWriter().close();
			return "getMenDianMingXi";
		} else {

			String hql = "from XiaoShouMingXi x where x.dingdan.id=" + id;
			lists2 = mingXiService.getAllMingXi(hql);
			JSONArray childArray = new JSONArray();
			for (XiaoShouMingXi xiaoShouMingXi : lists2) {
				childArray.add(xiaoShouMingXi);
			}
			json = childArray.toString();
			ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
			ServletActionContext.getResponse().setContentType("text/json");
			ServletActionContext.getResponse().getWriter().write(json);
			ServletActionContext.getResponse().getWriter().flush();
			ServletActionContext.getResponse().getWriter().close();

			return "getMenDianMingXi";
		}

		/*
		 * MenDian menDian=(((User)
		 * session.get("user")).getRenquanxian().getMenDian());
		 * System.out.println(gid+"aaaaaaaaa"); if(gid!=null){
		 * lists2=mingXiService.getAllMingXi(
		 * "from XiaoShouMingXi x where x.goods.id="+gid+
		 * "and x.dingdan.menDian.id="+menDian.getId());
		 * lists=mingXiService.getMenDian(
		 * "from XiaoShouMingXi x where x.goods.id="+gid+
		 * "and x.dingdan.menDian.id="+menDian.getId(), page, rows); }else{
		 * lists2=mingXiService.getAllMingXi(
		 * "from XiaoShouMingXi x where x.dingdan.menDian.id="+menDian.getId());
		 * lists=mingXiService.getMenDian(
		 * "from XiaoShouMingXi x where x.dingdan.menDian.id="+menDian.getId(),
		 * page, rows);
		 * System.out.println(lists.size()+"asssdfasdfasfasdfasdfasdfasdf"); }
		 * maps.put("rows", lists); maps.put("total", lists2.size()); return
		 * "getMenDianMingXi";
		 */
	}

	public String getZongBuMingxi() throws IOException {
		String json = null;
		JSONArray paArray = new JSONArray();
		List<MenDian> menDians = menDianService.getAllMenDian();
		for (int i = 1; i < menDians.size(); i++) {
			MenDian menDian = menDians.get(i);
			JSONArray rootArray = new JSONArray();
			List<Dingdan> listss = dingDanService.getMenDianDingdan("from Dingdan d where d.menDian.id=" + menDian.id);
			if (listss.size() > 0) {
				for (Dingdan dingdan : listss) {
					/*String hql = "from XiaoShouMingXi x where x.dingdan.id=" + dingdan.getId();
					lists2 = mingXiService.getAllMingXi(hql);
					JSONArray childArray = new JSONArray();
					for (XiaoShouMingXi xiaoShouMingXi : lists2) {
						JSONObject currentObj3 = JSONObject.fromObject(xiaoShouMingXi);
						childArray.add(currentObj3);
					}
					JSONObject currentObj = JSONObject.fromObject(dingdan);
					currentObj.put("children", childArray);
					currentObj.put("state", "closed");*/
					JSONObject currentObj = JSONObject.fromObject(dingdan);
					rootArray.add(currentObj);
				}

				JSONObject currentObj1 = JSONObject.fromObject(menDian);
				currentObj1.put("children", rootArray);
				currentObj1.put("state", "closed");
				paArray.add(currentObj1);
			} else {
				paArray.add(menDian);
			}
		}
		json = paArray.toString();
		ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
		ServletActionContext.getResponse().setContentType("text/json");
		ServletActionContext.getResponse().getWriter().write(json);
		ServletActionContext.getResponse().getWriter().flush();
		ServletActionContext.getResponse().getWriter().close();
		/*
		 * String hql=null; if(gid==null||gid.equals("")){ hql=
		 * "from XiaoShouMingXi x where 1=1"; }else{ hql=
		 * "from XiaoShouMingXi x where 1=1 and x.goods.id="+gid;
		 * System.out.println("1111111111111111111111111111111111111"); }
		 * 
		 * if((cid==null||cid.equals(""))&&(mid==null||mid.equals(""))){
		 * lists2=mingXiService.getAllMingXi(hql);
		 * lists=mingXiService.getMany(hql,page,rows); }else
		 * if((mid==null||mid.equals(""))){
		 * lists2=mingXiService.getAllMingXi(hql+" and x.dingdan.customer.id ="
		 * +cid ); lists=mingXiService.getMany(hql+
		 * " and x.dingdan.customer.id ="+cid , page, rows); }else
		 * if((cid==null||cid.equals(""))){
		 * lists2=mingXiService.getAllMingXi(hql+" and x.dingdan.menDian.id ="
		 * +mid ); lists=mingXiService.getMany(hql+" and x.dingdan.menDian.id ="
		 * +mid , page, rows); }else{ lists2=mingXiService.getAllMingXi(hql+
		 * " and x.dingdan.menDian.id ="+mid +" and x.dingdan.customer.id ="+cid
		 * ); lists=mingXiService.getMany(hql+" and x.dingdan.menDian.id ="+mid
		 * +" and x.dingdan.customer.id ="+cid, page, rows); } maps.put("rows",
		 * lists); maps.put("total", lists2.size());
		 * System.out.println(lists.size()+"6666666666666666666");
		 */
		return "getZongBuMingxi";
	}
	public String getMingXi(){
		System.out.println(did+"ccccccccccccccccccc");
		String hql = "from XiaoShouMingXi x where x.dingdan.id=" +did;
		lists2 = mingXiService.getAllMingXi(hql);
		lists=mingXiService.getMany(hql,page,rows);
		maps.put("rows",lists);
		maps.put("total", lists2.size());
	    return 	"getMingXi";
	}
}
