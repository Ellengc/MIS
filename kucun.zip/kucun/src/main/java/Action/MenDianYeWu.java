package Action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import Entity.Goods;
import Entity.IsGoods;
import Entity.LuruBiao;
import Entity.MenAndKucun;
import Entity.MenDian;
import Entity.Supply;
import Entity.User;
import Service.GoodsService;
import Service.IsGoodsService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import util.SearchBackge;

public class MenDianYeWu extends BaseAction<MenAndKucun> {

	public int id;
	public String gid;
	public String mid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGid() {
		return gid;
	}

	public void setGid(String gid) {
		this.gid = gid;
	}

	List<IsGoods> listss=new ArrayList<IsGoods>();
	
	public List<IsGoods> getListss() {
		return listss;
	}

	public void setListss(List<IsGoods> listss) {
		this.listss = listss;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getAllKuCun() throws IOException {
		System.out.println(mid + "aaaaaa" + gid);
		String json = null;
		JSONArray rootArray = new JSONArray();
		if (id == 0) {
			// gid ��Ϊ��
			if ((gid != null && !gid.equals(""))) {
				//gid��mid�������ǿ�
				if (!mid.equals("") && mid != null) {
					String canshu[][] = { { "gid", "mid" }, { gid, mid } };
					String hql = "from MenAndKucun m where gid=" + gid + " and mid=" + mid;
					lists = kuCunService.getAllKuCun(hql, page, rows);
					lists2 = kuCunService.getAll(hql);
					maps.put("rows", lists);
					maps.put("total", lists2.size());
				} else {
					List<MenDian> menDians =  menDianService.getAllMenDian();
					for (int i=1;i<menDians.size();i++){
						MenDian menDian=menDians.get(i);
						String hql = "from MenAndKucun m where m.menDian.id=" + menDian.getId()+" and m.goods.id="+gid;
						lists2 = kuCunService.getAll(hql);
						JSONArray childArray = new JSONArray();
						for (MenAndKucun menAndKucun : lists2) {
							childArray.add(menAndKucun);
						}
						JSONObject currentObj = JSONObject.fromObject(menDian);
						currentObj.put("children", childArray );
						currentObj.put("state", "closed");
						rootArray.add(currentObj);
					}
					json = rootArray.toString();
					ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
					ServletActionContext.getResponse().setContentType("text/json");
					ServletActionContext.getResponse().getWriter().write(json);
					ServletActionContext.getResponse().getWriter().flush();
					ServletActionContext.getResponse().getWriter().close();

				}
				/*
				 * String hql="from MenAndKucun m where m.menDian.id="+mid+
				 * " and m.goods.id="+gid; lists=kuCunService.getAllKuCun(hql,
				 * page, rows); lists2=kuCunService.getAll(hql);
				 * maps.put("rows", lists); maps.put("total", lists2.size());
				 */
				// mid ��Ϊ��
			} else {
				//gidΪ�գ�mid��Ϊ��
				if (mid!= null&&!mid.equals("") ) {
					List<IsGoods> listss = isGoodsService.getAll();
					for (IsGoods isGoods2 : listss) {
						String hql = "from MenAndKucun m where m.menDian.id=" + mid + "and m.goods.parentGoods.id="
								+ isGoods2.getId();
						lists2 = kuCunService.getAll(hql);
						JSONArray childArray = new JSONArray();
						for (MenAndKucun menAndKucun : lists2) {
							childArray.add(menAndKucun);
						}
						JSONObject currentObj = JSONObject.fromObject(isGoods2);
						currentObj.put("children", childArray);
						rootArray.add(currentObj);
					}
					json = rootArray.toString();
					ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
					ServletActionContext.getResponse().setContentType("text/json");
					ServletActionContext.getResponse().getWriter().write(json);
					ServletActionContext.getResponse().getWriter().flush();
					ServletActionContext.getResponse().getWriter().close();
					//��Ϊ��
				} else {
					List<MenDian> menDians =  menDianService.getAllMenDian();
					for (int i=1;i<menDians.size();i++){
						MenDian menDian=menDians.get(i);
						String hql = "from MenAndKucun m where m.menDian.id=" + menDian.getId();
						lists2 = kuCunService.getAll(hql);
						JSONArray childArray = new JSONArray();
						for (MenAndKucun menAndKucun : lists2) {
							childArray.add(menAndKucun);
						}
						JSONObject currentObj = JSONObject.fromObject(menDian);
						currentObj.put("children", childArray );
						currentObj.put("state", "closed");
						rootArray.add(currentObj);
					}
					json = rootArray.toString();
					ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
					ServletActionContext.getResponse().setContentType("text/json");
					ServletActionContext.getResponse().getWriter().write(json);
					ServletActionContext.getResponse().getWriter().flush();
					ServletActionContext.getResponse().getWriter().close();

				}
			}
			return "getAllKuCun";
		} else {
			/*List<IsGoods> listss = isGoodsService.getAll();
			for (IsGoods isGoods2 : listss) {
				String hql = "from MenAndKucun m where m.menDian.id=" + id + "and m.goods.parentGoods.id="
						+ isGoods2.getId();
				lists2 = kuCunService.getAll(hql);
				JSONArray childArray = new JSONArray();
				for (MenAndKucun menAndKucun : lists2) {
					childArray.add(menAndKucun);
				}
				JSONObject currentObj = JSONObject.fromObject(isGoods2);
				currentObj.put("children", childArray);
				rootArray.add(currentObj);
			}
			json = rootArray.toString();
			ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
			ServletActionContext.getResponse().setContentType("text/json");
			ServletActionContext.getResponse().getWriter().write(json);
			ServletActionContext.getResponse().getWriter().flush();
			ServletActionContext.getResponse().getWriter().close();
			*/
			
			/*List<IsGoods> listss = isGoodsService.getAll();
			JSONArray rootArray2 = new JSONArray();
			for (IsGoods isGoods2 : listss) {
			   String hql = "from MenAndKucun m where m.menDian.id=" + menDian.getId()
						+ "and m.goods.parentGoods.id=" + isGoods2.getId();
				lists2 = kuCunService.getAll(hql);
				JSONArray childArray = new JSONArray();
				for (MenAndKucun menAndKucun : lists2) {
					childArray.add(menAndKucun);
				}
				JSONObject currentObj = JSONObject.fromObject(isGoods2);
				currentObj.put("children", childArray);
				rootArray2.add(isGoods2);
			}
			JSONObject currentObj2 = JSONObject.fromObject(menDian);
			currentObj2.put("children",rootArray2);*/
			return "getAllKuCun";
		}

		/*
		 * if((String.valueOf(((User)
		 * session.get("user")).getRenquanxian().getMenDian().getId())).equals(
		 * "1")){ SearchBackge searchBackge=new SearchBackge(); String
		 * canshu[][]={{"gid","mid"},{gid,mid}}; String hql=
		 * searchBackge.selectByParam(canshu,"MenAndKucun"); String hql2=hql+
		 * " and menDian.id!=1 "; lists=kuCunService.getAllKuCun(hql2, page,
		 * rows); lists2=kuCunService.getAll(hql2); }else{
		 * mid=(String.valueOf(((User)
		 * session.get("user")).getRenquanxian().getMenDian().getId()));
		 * SearchBackge searchBackge=new SearchBackge(); String
		 * canshu[][]={{"gid","mid"},{gid,mid}}; String hql=
		 * searchBackge.selectByParam(canshu,"MenAndKucun");
		 * lists=kuCunService.getAllKuCun(hql, page, rows);
		 * lists2=kuCunService.getAll(hql);
		 * 
		 * } maps.put("rows", lists); maps.put("total", lists2.size());
		 */

	}

	public String supply() {
		model = kuCunService.getKuCun(id);
		model.setState2(1);
		kuCunService.update(model);
		Date date = new Date();
		Supply supply = new Supply("���뷢��", date, model);
		supplyService.save(supply);
		return "supply";
	}

	public String getZongBuKuCun() throws IOException {
		String json = null;
		JSONArray rootArray = new JSONArray();

		if (id == 0) {
			if (gid != null && !gid.equals("")) {
				String hql = "from MenAndKucun m where m.menDian.id=" + 1 + " and m.goods.id=" + gid;
				lists = kuCunService.getAllKuCun(hql, page, rows);
				lists2 = kuCunService.getAll(hql);
				maps.put("rows", lists);
				maps.put("total", lists2.size());
			} else {
				List<IsGoods> listss = isGoodsService.getAll();
				for (IsGoods isGoods2 : listss) {
					String hql = "from MenAndKucun m where m.menDian.id=" + 1 + "and m.goods.parentGoods.id="
							+ isGoods2.getId();
					lists2 = kuCunService.getAll(hql);
					JSONArray childArray = new JSONArray();
					for (MenAndKucun menAndKucun : lists2) {
						childArray.add(menAndKucun);
					}
					JSONObject currentObj = JSONObject.fromObject(isGoods2);
					currentObj.put("state", "closed");
					currentObj.put("children", childArray);
					rootArray.add(currentObj);
				}
				json = rootArray.toString();
				ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
				ServletActionContext.getResponse().setContentType("text/json");
				ServletActionContext.getResponse().getWriter().write(json);
				ServletActionContext.getResponse().getWriter().flush();
				ServletActionContext.getResponse().getWriter().close();

			}
			return "getZongBuKuCun";
		} else {
			return "getZongBuKuCun";
		}

	}

	/*
	 * String hql=null; System.out.println(gid); if(gid!=null&&!gid.equals("")){
	 * hql="from MenAndKucun m where m.menDian.id=1  and m.goods.id="+gid;
	 * }else{ hql="from MenAndKucun m where m.menDian.id=1"; }
	 * lists=kuCunService.getAllKuCun(hql, page, rows);
	 * lists2=kuCunService.getAll(hql); maps.put("rows", lists);
	 * maps.put("total", lists2.size()); return "getZongBuKuCun"; }
	 */
	public String getTreeDate() throws IOException {

		String json = null;
		JSONArray rootArray = new JSONArray();
		mid = (String.valueOf(((User) session.get("user")).getRenquanxian().getMenDian().getId()));
		if (id == 0) {
			if (gid != null && !gid.equals("")) {
				String hql = "from MenAndKucun m where m.menDian.id=" + mid + " and m.goods.id=" + gid;
				lists = kuCunService.getAllKuCun(hql, page, rows);
				lists2 = kuCunService.getAll(hql);
				maps.put("rows", lists);
				maps.put("total", lists2.size());
			} else {
				List<IsGoods> listss = isGoodsService.getAll();
				for (IsGoods isGoods2 : listss) {
					String hql = "from MenAndKucun m where m.menDian.id=" + mid + "and m.goods.parentGoods.id="
							+ isGoods2.getId();
					lists2 = kuCunService.getAll(hql);
					JSONArray childArray = new JSONArray();
					for (MenAndKucun menAndKucun : lists2) {
						childArray.add(menAndKucun);
					}
					JSONObject currentObj = JSONObject.fromObject(isGoods2);
					currentObj.put("state", "closed");
					currentObj.put("children", childArray);
					rootArray.add(currentObj);
				}
				json = rootArray.toString();
				ServletActionContext.getResponse().setCharacterEncoding("UTF-8");
				ServletActionContext.getResponse().setContentType("text/json");
				ServletActionContext.getResponse().getWriter().write(json);
				ServletActionContext.getResponse().getWriter().flush();
				ServletActionContext.getResponse().getWriter().close();

			}
			return "getTreeDate";
		} else {
			return "getTreeDate";
		}

	}

}
