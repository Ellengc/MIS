package Action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Entity.Goods;
import Entity.LuruBiao;
import Entity.MenAndKucun;
import Entity.MenDian;
import Entity.User;
import util.SearchBackge;

public class MenDianAction extends BaseAction<MenDian>{
	
	public String  mid;
	public String gid;
	
	int a=0;


	public String getAllMenDian(){
	
		lists=menDianService.getAllMenDian();
		lists.remove(0);
		return "getAllMenDian";
	}
	
    
	
}
