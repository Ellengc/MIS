package ServiceImp;

import java.io.Serializable;
import java.util.List;

import Dao.MingXiDao;
import Entity.XiaoShouMingXi;
import Service.MingXiService;

public class MingXiServiceImpl implements MingXiService{
   public MingXiDao mingXiDao;

public void setMingXiDao(MingXiDao mingXiDao) {
	this.mingXiDao = mingXiDao;
}
   public  Serializable addMingXi(XiaoShouMingXi entity){
	   return mingXiDao.save(entity);
   }
   public List<XiaoShouMingXi> getMany(String hql,int pageNo,int pageSize){
	   return mingXiDao.findByPage(hql, pageNo, pageSize);
   }
   
   
   public List<XiaoShouMingXi> getMenDian(String hql,int pageNo,int pageSize){
	   return mingXiDao.findByPage(hql, pageNo, pageSize);
   }
   public List<XiaoShouMingXi> getAllMingXi(String hql){
	   return mingXiDao.find(hql);
   }
}
