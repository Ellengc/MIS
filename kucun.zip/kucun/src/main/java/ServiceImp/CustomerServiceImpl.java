package ServiceImp;

import java.io.Serializable;
import java.util.List;

import Dao.CustomerDao;
import Entity.Customer;
import Service.CustomerService;

public class CustomerServiceImpl implements CustomerService{
  public CustomerDao customerDao;

public void setCustomerDao(CustomerDao customerDao) {
	this.customerDao = customerDao;
}
  public List<Customer> getAllCustomers(){
	  
	  return customerDao.findAll(Customer.class);
  }
  
  public  Serializable addOneCustomer(Customer customer ){
	  return  customerDao.save(customer);
  }
  public Customer getbyid(int id) {
	return customerDao.get(Customer.class, id);
}
}
