package ServiceImp;

import java.io.Serializable;
import java.util.List;

import Dao.DingDanDao;
import Entity.Dingdan;
import Service.DingDanService;

public class DingDanServiceImpl implements DingDanService{
  public DingDanDao dingDanDao;

public void setDingDanDao(DingDanDao dingDanDao) {
	this.dingDanDao = dingDanDao;
}
  
  public  Serializable addDingdan(Dingdan entity){
	  
	  return dingDanDao.save(entity);
  }
  public List<Dingdan> getMenDian(int mid,int pageNo,int pageSize){
	  return dingDanDao.findByPage("from Dingdan d where d.mid="+mid, pageNo, pageSize);
  }
  public List<Dingdan> getMenDianDingdan(String hql){
	  return dingDanDao.find(hql);
  }
  public Dingdan getOneById(int id){
	  return dingDanDao.get(Dingdan.class, id);
  }
}
