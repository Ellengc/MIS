package ServiceImp;

import java.util.List;

import Dao.KuCunDao;
import Entity.Goods;
import Entity.MenAndKucun;
import Entity.MenDian;
import Service.KuCunService;


public class KuCunServiceImpl implements KuCunService {
  
	private KuCunDao kuCunDao;

	public void setKuCunDao(KuCunDao kuCunDao) {
		this.kuCunDao = kuCunDao;
	}
	@Override
	public List<MenAndKucun> getAllKuCun(String hql,int pageNo,int pageSize){
		
		return kuCunDao.findByPage(hql, pageNo, pageSize);
	}
	
	@Override
     public MenAndKucun getOneKuCun(String hql){
		
		return kuCunDao.getOne(hql);
	}
	
	public void update(MenAndKucun entity){
		
		 kuCunDao.update(entity);
	}
	public MenAndKucun getKuCun(int id){
		return kuCunDao.get(MenAndKucun.class, id);
	}
	
	public List<MenAndKucun> getAll(String hql){
		return kuCunDao.find(hql);
	}

}
