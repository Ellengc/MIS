package ServiceImp;

import java.io.Serializable;
import java.util.List;

import Dao.LuRuDao;
import Entity.LuruBiao;
import Service.LuRuService;

public class LuRuServiceImpl implements LuRuService{
    
	public LuRuDao luRuDao;



	public void setLuRuDao(LuRuDao luRuDao) {
		this.luRuDao = luRuDao;
	}
	
	public  Serializable  save(LuruBiao luruBiao){
		
		return luRuDao.save(luruBiao);
	}
	
	public List<LuruBiao> getAllLuRu(){
		return luRuDao.findAll(LuruBiao.class);
	}
	
	public void update(LuruBiao luruBiao){
		 luRuDao.update(luruBiao);
	}
	
	public LuruBiao getOne(int id){
		return luRuDao.get(LuruBiao.class, id);
	}
	
	public void deletes(String ids){
		 luRuDao.deletes(LuruBiao.class, ids);
	}
	public void deleteAll(){
		luRuDao.deleteAll(LuruBiao.class);
	}
}
