package ServiceImp;

import java.util.List;

import Dao.SupplyDao;
import Entity.Supply;
import Entity.XiaoShouMingXi;
import Service.SupplyService;

public class SupplyServiceImpl implements SupplyService{
   public SupplyDao supplyDao;

public void setSupplyDao(SupplyDao supplyDao) {
	this.supplyDao = supplyDao;
}
   @Override
   public void save(Supply entity){
	   supplyDao.save(entity);
   }
   
   public List<Supply> getAllSupply(){
	   return supplyDao.findAll(Supply.class);
   }
   
   public Supply getById(int id){
	   
	   return supplyDao.get(Supply.class, id);
   }
   public void update(Supply entity){
	   supplyDao.update(entity);
   }

}
