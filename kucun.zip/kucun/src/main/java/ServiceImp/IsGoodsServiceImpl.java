package ServiceImp;

import java.util.List;

import Dao.IsGoodsDao;
import Entity.IsGoods;
import Service.IsGoodsService;

public class IsGoodsServiceImpl implements IsGoodsService{
 public  IsGoodsDao isGoodsDao;

public void setIsGoodsDao(IsGoodsDao isGoodsDao) {
	this.isGoodsDao = isGoodsDao;
}
 public List<IsGoods> getAll(){
	 return isGoodsDao.findAll(IsGoods.class);
 }
 public IsGoods getOne(int id){
	 return isGoodsDao.get(IsGoods.class, id);
 }
}
