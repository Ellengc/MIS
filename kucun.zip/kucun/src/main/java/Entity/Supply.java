package Entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Supply {
	@Id
	@GeneratedValue(generator="id")
   @GenericGenerator(name="id",strategy="increment")
   public int id;
   public String state;
   public Date date;
   @OneToOne(cascade=CascadeType.ALL)
   @JoinColumn(name="menAndKucun_id") 
   public MenAndKucun menAndKucun;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public MenAndKucun getMenAndKucun() {
	return menAndKucun;
}
public void setMenAndKucun(MenAndKucun menAndKucun) {
	this.menAndKucun = menAndKucun;
}
public Supply(String state, Date date, MenAndKucun menAndKucun) {
	super();
	this.state = state;
	this.date = date;
	this.menAndKucun = menAndKucun;
}
public Supply() {
	super();
}
   
}
