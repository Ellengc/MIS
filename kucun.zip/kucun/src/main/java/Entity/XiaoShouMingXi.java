package Entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;
@Entity
public class XiaoShouMingXi {
	@Id
	@GeneratedValue(generator="id")
	@GenericGenerator(name="id",strategy="increment")
	public int id;
    
	
    public int number;
	
    
    @ManyToOne(cascade={CascadeType.ALL},fetch=FetchType.EAGER)
    @JoinColumn(name="Gid",referencedColumnName="id")
	public Goods goods;
    
    @ManyToOne(cascade={CascadeType.ALL},fetch=FetchType.EAGER)
    @JoinColumn(name="Did",referencedColumnName="id")
    public Dingdan dingdan;

    public Double price;
    
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public Goods getGoods() {
		return goods;
	}

	public void setGoods(Goods goods) {
		this.goods = goods;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public Dingdan getDingdan() {
		return dingdan;
	}

	public void setDingdan(Dingdan dingdan) {
		this.dingdan = dingdan;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public XiaoShouMingXi(int number, Goods goods, Dingdan dingdan, Double price) {
		super();
		this.number = number;
		this.goods = goods;
		this.dingdan = dingdan;
		this.price = price;
	}

	public XiaoShouMingXi() {
		super();
	}


	
	
}
