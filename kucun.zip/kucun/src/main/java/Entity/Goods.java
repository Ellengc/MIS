package Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Goods {
	@Id
	@GeneratedValue(generator="id")
	@GenericGenerator(name="id",strategy="increment")
  public int id;
  
  public String name;
  
  public String price;
  @ManyToOne(cascade={CascadeType.ALL},fetch=FetchType.EAGER)
  @JoinColumn(name="pid",referencedColumnName="id")
  public IsGoods parentGoods;
  
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPrice() {
	return price;
}

public void setPrice(String price) {
	this.price = price;
}

public IsGoods getParentGoods() {
	return parentGoods;
}

public void setParentGoods(IsGoods parentGoods) {
	this.parentGoods = parentGoods;
}
  
  
}
