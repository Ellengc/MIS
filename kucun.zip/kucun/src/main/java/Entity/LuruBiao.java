package Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class LuruBiao {
	

	@Id
	@GeneratedValue(generator = "id")
	@GenericGenerator(name = "id", strategy = "increment")
	public int id;
    
	
	@ManyToOne(cascade={CascadeType.ALL},fetch=FetchType.EAGER)
	@JoinColumn(name="gid",referencedColumnName="id")
	public Goods good;

	public int kuCun;
	@ManyToOne(cascade={CascadeType.ALL},fetch=FetchType.EAGER)
	@JoinColumn(name="Cid",referencedColumnName="id")
	public Customer customer;
	
	public int ShouLiang;

	public Double price;

	public String address;

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public int getShouLiang() {
		return ShouLiang;
	}

	public void setShouLiang(int shouLiang) {
		ShouLiang = shouLiang;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LuruBiao() {
		super();
	}


	public Goods getGood() {
		return good;
	}

	public void setGood(Goods good) {
		this.good = good;
	}

	public int getKuCun() {
		return kuCun;
	}

	public void setKuCun(int kuCun) {
		this.kuCun = kuCun;
	}



	public LuruBiao(Goods good, int kuCun, int shouLiang, Double price, String address) {
		super();
		this.good = good;
		this.kuCun = kuCun;
		ShouLiang = shouLiang;
		this.price = price;
		this.address = address;
	}


	public LuruBiao(Goods good, int kuCun, int shouLiang, Double price) {
		super();
		this.good = good;
		this.kuCun = kuCun;
		ShouLiang = shouLiang;
		this.price = price;
	
	}
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
  
}
