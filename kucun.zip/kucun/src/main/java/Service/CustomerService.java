package Service;

import java.io.Serializable;
import java.util.List;

import Entity.Customer;

public interface CustomerService {
	  public List<Customer> getAllCustomers();
	  public Serializable addOneCustomer(Customer customer );
	  public Customer getbyid(int id);
}
