package Service;

import java.util.List;

import Entity.Supply;
import Entity.XiaoShouMingXi;

public interface SupplyService {

	   void save(Supply entity);
	   public List<Supply> getAllSupply();
	   public Supply getById(int id);
	   public void update(Supply entity);
     
}
