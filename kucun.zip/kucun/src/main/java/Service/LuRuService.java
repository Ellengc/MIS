package Service;

import java.io.Serializable;
import java.util.List;

import Entity.LuruBiao;

public interface LuRuService {
	public  Serializable  save(LuruBiao luruBiao);
	public List<LuruBiao> getAllLuRu();
	public void update(LuruBiao luruBiao);
	public LuruBiao getOne(int id);
	public void deletes(String ids);
	public void deleteAll();
}
