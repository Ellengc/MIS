package Service;

import java.io.Serializable;
import java.util.List;

import Entity.XiaoShouMingXi;

public interface MingXiService {
	 public  Serializable addMingXi(XiaoShouMingXi entity);
	 public List<XiaoShouMingXi> getMenDian(String hql,int pageNo,int pageSize);
	   public List<XiaoShouMingXi> getMany(String hql,int pageNo,int pageSize);
	   public List<XiaoShouMingXi> getAllMingXi(String hql);
}
