package Service;

import java.util.List;

import Entity.MenDian;

public interface MenDianService {
	

	List<MenDian> getAllMenDian();
	
}
