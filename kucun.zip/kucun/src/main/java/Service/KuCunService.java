package Service;

import java.util.List;

import Entity.MenAndKucun;

public interface KuCunService {
	public List<MenAndKucun> getAllKuCun(String hql,int pageNo,int pageSize);
	
	MenAndKucun getOneKuCun(String hql);
	
	public void update(MenAndKucun entity);
	
	public MenAndKucun getKuCun(int id);
	public List<MenAndKucun> getAll(String hql);
}
