package Service;

import java.io.Serializable;
import java.util.List;

import Entity.Dingdan;

public interface DingDanService {
	public  Serializable addDingdan(Dingdan entity);
	public List<Dingdan> getMenDian(int mid,int pageNo,int pageSize);
	public List<Dingdan> getMenDianDingdan(String hql);
	public Dingdan getOneById(int id);
}
