package Service;

import java.util.List;

import Entity.IsGoods;

public interface IsGoodsService {
	 public List<IsGoods> getAll();
	 public IsGoods getOne(int id);
}
