package Service;

import Entity.User;

public interface UserService {
	public User geyByUsername(String username);
}
