package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.GoodsDao;
import Entity.Goods;

public class GoodsDaoImpl extends BaseHibernate4DaoImpl<Goods> implements GoodsDao {

}
