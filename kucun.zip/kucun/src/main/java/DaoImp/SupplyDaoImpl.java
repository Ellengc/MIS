package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.SupplyDao;
import Entity.Supply;

public class SupplyDaoImpl extends BaseHibernate4DaoImpl<Supply> implements SupplyDao{

}
