package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.LuRuDao;
import Entity.LuruBiao;

public class LuRuDaoImpl extends BaseHibernate4DaoImpl<LuruBiao> implements LuRuDao{

}
