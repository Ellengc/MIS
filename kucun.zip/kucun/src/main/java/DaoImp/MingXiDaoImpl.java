package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.MingXiDao;
import Entity.XiaoShouMingXi;

public class MingXiDaoImpl extends BaseHibernate4DaoImpl<XiaoShouMingXi> implements MingXiDao{

}
