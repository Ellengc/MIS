package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.DingDanDao;
import Entity.Dingdan;

public final class DingDanDaoImpl extends BaseHibernate4DaoImpl<Dingdan> implements DingDanDao{

}
