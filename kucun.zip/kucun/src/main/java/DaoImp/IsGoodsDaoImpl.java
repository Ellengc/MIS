package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.IsGoodsDao;
import Entity.IsGoods;

public class IsGoodsDaoImpl extends BaseHibernate4DaoImpl<IsGoods> implements IsGoodsDao{
   
}
