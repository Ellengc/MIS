package DaoImp;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.KuCunDao;
import Entity.Goods;
import Entity.MenAndKucun;
import Entity.MenDian;

public class KuCunDaoImpl extends BaseHibernate4DaoImpl<MenAndKucun> implements KuCunDao {


}
