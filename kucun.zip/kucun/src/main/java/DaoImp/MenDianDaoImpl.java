package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.MenDianDao;
import Entity.MenDian;

public class MenDianDaoImpl extends BaseHibernate4DaoImpl<MenDian> implements MenDianDao{
    
}
