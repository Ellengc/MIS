package DaoImp;

import BaseDaoImp.BaseHibernate4DaoImpl;
import Dao.CustomerDao;
import Entity.Customer;

public class CustomerDaoImpl extends BaseHibernate4DaoImpl<Customer> implements CustomerDao{

}
