CREATE DATABASE  IF NOT EXISTS `kucun` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `kucun`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: kucun
-- ------------------------------------------------------
-- Server version	5.7.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `caddress` varchar(255) DEFAULT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `cphone` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'江苏南通','白胡子',185686484),(8,'江苏徐州','艾斯',1895224731),(9,'上海','黑胡子',14654897);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dingdan`
--

DROP TABLE IF EXISTS `dingdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dingdan` (
  `id` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `Cid` int(11) DEFAULT NULL,
  `Mid` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_p1ygfavx1qlbwr9qc4pr1nbmq` (`Cid`),
  KEY `FK_nexp1s068wlv2r64ggxds7flj` (`Mid`),
  CONSTRAINT `FK_nexp1s068wlv2r64ggxds7flj` FOREIGN KEY (`Mid`) REFERENCES `mendian` (`id`),
  CONSTRAINT `FK_p1ygfavx1qlbwr9qc4pr1nbmq` FOREIGN KEY (`Cid`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dingdan`
--

LOCK TABLES `dingdan` WRITE;
/*!40000 ALTER TABLE `dingdan` DISABLE KEYS */;
INSERT INTO `dingdan` VALUES (1,'2016-12-05 14:56:56',1,2,'南通'),(7,'2016-12-05 15:07:19',1,2,'上海'),(8,'2016-12-05 15:09:26',8,2,'徐州'),(9,'2016-12-05 15:13:05',9,5,'广东'),(10,'2016-12-05 15:14:49',8,6,'重庆'),(11,'2016-12-05 17:29:50',1,2,'成都'),(12,'2016-12-07 00:00:00',1,2,'北京'),(13,'2016-12-14 00:00:00',8,2,'asdffasdf');
/*!40000 ALTER TABLE `dingdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_30g7i8n5k15awbnicwag4ttbb` (`pid`),
  CONSTRAINT `FK_30g7i8n5k15awbnicwag4ttbb` FOREIGN KEY (`pid`) REFERENCES `isgoods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (1,'海尔冰箱','3000',1),(2,'海尔彩电','2800',2),(3,'海尔洗衣机','4000',3),(4,'海尔电饭锅','3800',4),(5,'海尔空调','6000',5),(6,'海尔电冰箱','4800',6),(7,'海尔煤气灶','3200',7),(8,'格力冰箱','3000',1),(9,'格力彩电','2800',2),(10,'格力洗衣机','4000',3),(11,'格力电饭锅','3800',4),(12,'格力空调','6000',5),(13,'格力电冰箱','4800',6),(14,'格力煤气灶','3200',7),(15,'美的冰箱','3000',1),(16,'美的彩电','2800',2),(17,'美的洗衣机','4000',3),(18,'美的电饭锅','3800',4),(19,'美的空调','6000',5),(20,'美的电冰箱','4800',6),(21,'美的煤气灶','3200',7),(22,'乐视冰箱','3000',1),(23,'乐视彩电','2800',2),(24,'乐视电饭锅','3800',4),(25,'乐视空调','6000',5),(26,'乐视洗衣机','4000',3),(27,'乐视煤气灶','3200',7),(28,'乐视电冰箱','4800',6);
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `isgoods`
--

DROP TABLE IF EXISTS `isgoods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isgoods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `isgoods`
--

LOCK TABLES `isgoods` WRITE;
/*!40000 ALTER TABLE `isgoods` DISABLE KEYS */;
INSERT INTO `isgoods` VALUES (1,'冰箱',NULL),(2,'彩电',NULL),(3,'洗衣机',NULL),(4,'电饭锅',NULL),(5,'空调',NULL),(6,'电冰箱',NULL),(7,'煤气灶',NULL);
/*!40000 ALTER TABLE `isgoods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lurubiao`
--

DROP TABLE IF EXISTS `lurubiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lurubiao` (
  `id` int(11) NOT NULL,
  `ShouLiang` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `kuCun` int(11) NOT NULL,
  `price` double DEFAULT NULL,
  `Cid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_fjwv9936pxi14o1c35o9yo6cg` (`Cid`),
  KEY `FK_mpdo9k08sj437bd1nqpgf18q0` (`gid`),
  CONSTRAINT `FK_fjwv9936pxi14o1c35o9yo6cg` FOREIGN KEY (`Cid`) REFERENCES `customer` (`id`),
  CONSTRAINT `FK_mpdo9k08sj437bd1nqpgf18q0` FOREIGN KEY (`gid`) REFERENCES `goods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lurubiao`
--

LOCK TABLES `lurubiao` WRITE;
/*!40000 ALTER TABLE `lurubiao` DISABLE KEYS */;
/*!40000 ALTER TABLE `lurubiao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menandkucun`
--

DROP TABLE IF EXISTS `menandkucun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menandkucun` (
  `id` int(11) NOT NULL,
  `kucun` int(11) NOT NULL,
  `Gid` int(11) DEFAULT NULL,
  `Mid` int(11) DEFAULT NULL,
  `Q` int(11) NOT NULL,
  `ROP` int(11) NOT NULL,
  `lasttime` datetime DEFAULT NULL,
  `xuqiuyuce` int(11) NOT NULL,
  `state2` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_kfu17xpojhevhpnyvlq4l9hgk` (`Gid`),
  KEY `FK_iy3bbpdbi7hx9jaf7ktcdy2o` (`Mid`),
  CONSTRAINT `FK_iy3bbpdbi7hx9jaf7ktcdy2o` FOREIGN KEY (`Mid`) REFERENCES `mendian` (`id`),
  CONSTRAINT `FK_kfu17xpojhevhpnyvlq4l9hgk` FOREIGN KEY (`Gid`) REFERENCES `goods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menandkucun`
--

LOCK TABLES `menandkucun` WRITE;
/*!40000 ALTER TABLE `menandkucun` DISABLE KEYS */;
INSERT INTO `menandkucun` VALUES (1,1000,1,1,200,60,NULL,400,0),(2,1000,2,1,300,80,NULL,450,0),(3,1000,3,1,260,70,NULL,420,0),(4,1000,4,1,320,65,NULL,380,0),(5,1000,5,1,200,60,NULL,400,0),(6,1000,6,1,300,80,NULL,450,0),(7,1000,7,1,280,70,NULL,400,0),(8,2100,1,2,200,60,NULL,400,1),(9,1890,2,2,300,80,NULL,450,1),(10,1700,3,2,260,70,NULL,420,1),(11,2000,4,2,320,65,NULL,380,0),(12,2000,5,2,200,60,NULL,400,0),(13,300,6,2,300,80,NULL,450,0),(14,340,7,2,280,70,NULL,400,0),(15,100,1,3,200,60,NULL,400,0),(16,600,2,3,300,80,NULL,450,0),(17,120,3,3,260,70,NULL,420,0),(18,150,4,3,320,65,NULL,380,0),(19,100,5,3,200,60,NULL,400,0),(20,600,6,3,300,80,NULL,450,0),(21,500,7,3,280,70,NULL,400,0),(22,100,1,4,200,60,NULL,400,0),(23,600,2,4,300,80,NULL,450,0),(24,120,3,4,260,70,NULL,420,0),(25,150,4,4,320,65,NULL,380,0),(26,100,5,4,200,60,NULL,400,0),(27,600,6,4,300,80,NULL,450,0),(28,500,7,4,280,70,NULL,400,0),(29,-100,1,5,200,60,NULL,400,0),(30,600,2,5,300,80,NULL,450,0),(31,120,3,5,260,70,NULL,420,0),(32,-150,4,5,320,65,NULL,380,0),(33,-100,5,5,200,60,NULL,400,0),(34,600,6,5,300,80,NULL,450,0),(35,500,7,5,280,70,NULL,400,0),(36,100,1,6,200,60,NULL,400,0),(37,600,2,6,300,80,NULL,450,0),(38,20,3,6,260,70,NULL,420,2),(39,50,4,6,320,65,NULL,380,2),(40,100,5,6,200,60,NULL,400,0),(41,600,6,6,300,80,NULL,450,0),(42,500,7,6,280,70,NULL,400,0),(43,1000,8,1,200,60,NULL,400,0),(44,1000,9,1,300,80,NULL,450,0),(45,1000,10,1,260,70,NULL,420,0),(46,1000,11,1,320,65,NULL,380,0),(47,1000,12,1,200,60,NULL,400,0),(48,1000,13,1,300,80,NULL,450,0),(49,1000,14,1,280,70,NULL,400,0),(50,1000,15,1,200,60,NULL,400,0),(51,1000,16,1,300,80,NULL,450,0),(52,1000,17,1,260,70,NULL,420,0),(53,1000,18,1,320,65,NULL,380,0),(54,1000,19,1,200,60,NULL,400,0),(55,1000,20,1,300,80,NULL,450,0),(56,1000,21,1,280,70,NULL,400,0),(57,1000,22,1,200,60,NULL,400,0),(58,1000,23,1,300,80,NULL,450,0),(59,1000,24,1,260,70,NULL,420,0),(60,1000,25,1,320,65,NULL,380,0),(61,1000,26,1,200,60,NULL,400,0),(62,1000,27,1,300,80,NULL,450,0),(63,1000,28,1,280,70,NULL,400,0),(64,1000,8,2,200,60,NULL,400,0),(65,1000,9,2,300,80,NULL,450,0),(66,1000,10,2,260,70,NULL,420,0),(67,980,11,2,320,65,NULL,380,0),(68,1000,12,2,200,60,NULL,400,0),(69,1000,13,2,300,80,NULL,450,0),(70,1000,14,2,280,70,NULL,400,0),(71,1000,15,2,200,60,NULL,400,0),(72,1000,16,2,300,80,NULL,450,0),(73,1000,17,2,260,70,NULL,420,0),(74,1000,18,2,320,65,NULL,380,0),(75,1000,19,2,200,60,NULL,400,0),(76,1000,20,2,300,80,NULL,450,0),(77,1000,21,2,280,70,NULL,400,0),(78,1000,22,2,200,60,NULL,400,0),(79,1000,23,2,300,80,NULL,450,0),(80,1000,24,2,260,70,NULL,420,1),(81,1000,25,2,320,65,NULL,380,0),(82,1000,26,2,200,60,NULL,400,0),(83,1000,27,2,300,80,NULL,450,0),(84,1000,28,2,280,70,NULL,400,0),(85,1000,8,3,200,60,NULL,400,0),(86,1000,9,3,300,80,NULL,450,0),(87,1000,10,3,260,70,NULL,420,0),(88,980,11,3,320,65,NULL,380,0),(89,1000,12,3,200,60,NULL,400,0),(90,1000,13,3,300,80,NULL,450,0),(91,1000,14,3,280,70,NULL,400,0),(92,1000,15,3,200,60,NULL,400,0),(93,1000,16,3,300,80,NULL,450,0),(94,1000,17,3,260,70,NULL,420,0),(95,1000,18,3,320,65,NULL,380,0),(96,1000,19,3,200,60,NULL,400,0),(97,1000,20,3,300,80,NULL,450,0),(98,1000,21,3,280,70,NULL,400,0),(99,1000,22,3,200,60,NULL,400,0),(100,1000,23,3,300,80,NULL,450,0),(101,1000,24,3,260,70,NULL,420,1),(102,1000,25,3,320,65,NULL,380,0),(103,1000,26,3,200,60,NULL,400,0),(104,1000,27,3,300,80,NULL,450,0),(105,1000,28,3,280,70,NULL,400,0);
/*!40000 ALTER TABLE `menandkucun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mendian`
--

DROP TABLE IF EXISTS `mendian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mendian` (
  `id` int(11) NOT NULL,
  `idress` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mendian`
--

LOCK TABLES `mendian` WRITE;
/*!40000 ALTER TABLE `mendian` DISABLE KEYS */;
INSERT INTO `mendian` VALUES (1,'总部','总部'),(2,'江苏南通','南通家电旗舰店'),(3,'矿大南湖','矿大南湖企鹅店'),(4,'上海','上海浦东店'),(5,'南京','中山陵店'),(6,'重庆','朝天门店');
/*!40000 ALTER TABLE `mendian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `renquanxian`
--

DROP TABLE IF EXISTS `renquanxian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `renquanxian` (
  `id` int(11) NOT NULL,
  `idress` varchar(255) DEFAULT NULL,
  `iphone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `Mid` int(11) DEFAULT NULL,
  `ShenFen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_jm9bj9njhdx34iy4352v93ivp` (`Mid`),
  CONSTRAINT `FK_jm9bj9njhdx34iy4352v93ivp` FOREIGN KEY (`Mid`) REFERENCES `mendian` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `renquanxian`
--

LOCK TABLES `renquanxian` WRITE;
/*!40000 ALTER TABLE `renquanxian` DISABLE KEYS */;
INSERT INTO `renquanxian` VALUES (1,'松四','10086','张三',1,'1'),(2,'松二','10087','路飞',2,'2'),(3,'松一','10088','佐罗',3,'2'),(4,'松一','10089','巴基',4,'2'),(5,'松一','10090','拉布 ',5,'2'),(6,'松一','10090','关羽',6,'2'),(7,'松二','10087','乔巴',2,'2'),(8,'松一','10088','伊娃',3,'2'),(9,'松一','10089','龙',4,'2'),(10,'松一','10090','罗',5,'2'),(11,'松一','10090','基德',6,'2');
/*!40000 ALTER TABLE `renquanxian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supply`
--

DROP TABLE IF EXISTS `supply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supply` (
  `id` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `menAndKucun_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_o405vhtve2cm92ms8khj3k204` (`menAndKucun_id`),
  CONSTRAINT `FK_o405vhtve2cm92ms8khj3k204` FOREIGN KEY (`menAndKucun_id`) REFERENCES `menandkucun` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supply`
--

LOCK TABLES `supply` WRITE;
/*!40000 ALTER TABLE `supply` DISABLE KEYS */;
INSERT INTO `supply` VALUES (4,'2016-12-05 15:13:29','已发货',29),(5,'2016-12-05 15:13:36','申请发货',32),(6,'2016-12-05 15:13:38','申请发货',33),(7,'2016-12-05 16:09:52','已发货',38),(8,'2016-12-05 16:12:45','已发货',39),(9,'2016-12-05 17:24:37','已发货',8),(10,'2016-12-05 17:24:40','已发货',9),(11,'2016-12-07 20:18:11','申请发货',9),(12,'2016-12-07 20:21:46','申请发货',9),(13,'2016-12-07 20:50:44','申请发货',10),(14,'2016-12-07 20:51:29','申请发货',80),(15,'2016-12-08 19:23:51','申请发货',8);
/*!40000 ALTER TABLE `supply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_pf4u2lnodgaoykxdswfq1dik8` (`rid`),
  CONSTRAINT `FK_pf4u2lnodgaoykxdswfq1dik8` FOREIGN KEY (`rid`) REFERENCES `renquanxian` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'123456','namei',1),(2,'654321','shanzhi',2),(3,'456789','wusuopu',3),(4,'987654','qiaoba',4),(5,'111111','goging',5),(6,'222222','uzi',6);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xiaoshoumingxi`
--

DROP TABLE IF EXISTS `xiaoshoumingxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xiaoshoumingxi` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `price` double DEFAULT NULL,
  `Did` int(11) DEFAULT NULL,
  `Gid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_bx5mpuyif082s78c7k3pnp0gu` (`Did`),
  KEY `FK_9no8tpfr0fucuenqlksk70s4t` (`Gid`),
  CONSTRAINT `FK_9no8tpfr0fucuenqlksk70s4t` FOREIGN KEY (`Gid`) REFERENCES `goods` (`id`),
  CONSTRAINT `FK_bx5mpuyif082s78c7k3pnp0gu` FOREIGN KEY (`Did`) REFERENCES `dingdan` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xiaoshoumingxi`
--

LOCK TABLES `xiaoshoumingxi` WRITE;
/*!40000 ALTER TABLE `xiaoshoumingxi` DISABLE KEYS */;
INSERT INTO `xiaoshoumingxi` VALUES (1,100,4000,1,1),(2,50,5000,1,2),(3,120,3000,1,3),(9,100,2000,7,1),(10,100,6000,7,4),(11,200,3000,7,3),(12,200,3000,7,2),(13,200,2000,8,2),(14,300,3000,8,3),(15,200,2000,9,1),(16,200,3000,9,5),(17,300,5000,9,4),(18,100,2000,10,3),(19,100,5000,10,4),(20,100,2000,11,1),(21,150,5000,11,2),(22,20,40,12,11),(23,40,40,12,2),(24,20,400,13,2);
/*!40000 ALTER TABLE `xiaoshoumingxi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-15 14:22:52
